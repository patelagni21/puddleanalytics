// $(document).ready(function() {
//     $('a').click( function(e) {
//         e.preventDefault();
//         $("#hidden").show();
//     });
//     $('.close').click(function(){
//         $("#hidden").hide();
//     })
//   });
# https://github.com/square/square-python-sdk/
# pip install squareup